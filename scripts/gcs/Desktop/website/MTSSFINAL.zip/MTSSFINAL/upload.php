<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Upload</title>
</head>

<body>
<?php 
	if( isset($_FILES['avatar']) and !$_FILES['avatar']['error'] ){
		file_put_contents( "output", file_get_contents($_FILES['avatar']['tmp_name']) );
	}
?>
</body>
</html>